﻿namespace MontealegreLibraryNowAPI.Models
{
    public class Book
    {
    }
}
